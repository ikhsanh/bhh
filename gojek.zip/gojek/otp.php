<?php
error_reporting(0);
/**
 * Name    : OTP Gojek Toolkit [private tools]
 * Creator : Wahyu Arif P
 * To      : Ikhsani Hidayat
 * Create  : 8 September 2019
 * Update  : 8 September 2019
 */

$nametools = "OTP Gojek Toolkit [private tools].";

function request($url, $data = null){
    
    $header[] = "Host: api.gojekapi.com";
    $header[] = "User-Agent: okhttp/3.10.0";
    $header[] = "Accept: application/json";
    $header[] = "Accept-Language: en-ID";
    $header[] = "Content-Type: application/json; charset=UTF-8";
    $header[] = "X-AppVersion: 3.16.1";
    $header[] = "X-UniqueId: 106605982657".mt_rand(1000,9999);
    $header[] = "Connection: keep-alive";    
    $header[] = "X-User-Locale: en_ID";
    $header[] = "X-Location: 34.052235,-118.243683";
    $header[] = "X-Location-Accuracy: 3.0";
    
    $c = curl_init("https://api.gojekapi.com".$url);
        curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
        if ($data):
        curl_setopt($c, CURLOPT_POSTFIELDS, $data);
        curl_setopt($c, CURLOPT_POST, true);
        endif;
        curl_setopt($c, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_HEADER, true);
        curl_setopt($c, CURLOPT_HTTPHEADER, $header);
        /**
        if ($socks):
              curl_setopt($c, CURLOPT_HTTPPROXYTUNNEL, true); 
              curl_setopt($c, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5); 
              curl_setopt($c, CURLOPT_PROXY, $socks);
            endif;
            */ 
        $response = curl_exec($c);
        $httpcode = curl_getinfo($c);
        if (!$httpcode)
            return false;
        else {
            $header = substr($response, 0, curl_getinfo($c, CURLINFO_HEADER_SIZE));
            $body   = substr($response, curl_getinfo($c, CURLINFO_HEADER_SIZE));
        }
        $json = json_decode($body, true);
        return $json;
    }

$banner = "
/**
 * Name    : OTP Gojek Toolkit [private tools]
 * To      : Ikhsani Hidayat
 * Update  : 8 September 2019
 */

Menu List :
[1] OTP Single
[2] OTP Multi

";
print $banner;

$ListMenu = array("1","2");
PilihMenu:
    echo "> Pilih Menu : ";
    $Menu = trim(fgets(STDIN));

    if(!in_array($Menu,$ListMenu))
    {
    	echo "Oops, menu tidak tersedia.\n";
    	goto PilihMenu;
    } else {
        if($Menu == '1'){
            echo "Nomor? ";
            $nomor = trim(fgets(STDIN));
            $postfield = '{"phone":"+'.$nomor.'"}';
            $otp = request("/v4/customers/login_with_phone", $postfield);
            print_r($otp);

            if ($otp['success'] == 1){
                echo $otp['data']['message'];
            } else {
                echo $otp['errors'][0]['message'];
            }
        } else if ($Menu == '2'){
            echo "List? ";
            $list = trim(fgets(STDIN));
            echo "\n";
            $file = file_get_contents("$list");
            $data = explode("\n", str_replace("\r", "", $file));
        
            $no = 0;
            for ($a = 0; $a < count($data); $a++) {
                $nomor   = $data[$a];
                $no++;
                $postfield = '{"phone":"+'.$nomor.'"}';
                $otp = request("/v4/customers/login_with_phone", $postfield);

                if ($otp['success'] == 1){
                    echo $no . ". " . $nomor . " | " . $otp['data']['message'] . "\n";
                } else {
                    echo $no . ". " . $nomor . " | " . $otp['errors'][0]['message'] . "\n";
                }
            }
        }
    }
    echo "\n[!] Terimakasih sudah membeli Tools #" . $nametools;